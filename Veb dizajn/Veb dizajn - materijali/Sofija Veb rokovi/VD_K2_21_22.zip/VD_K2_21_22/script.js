function ispravanTekst(text) {
    return /[A-Z]+$/.test(text)
}

function zameni(tekst) {
    let ret = ''
    for (let i = 0; i < tekst.length; i++) {
        let char = tekst.charCodeAt(i) + 3
        if (char > 'Z'.charCodeAt(0)) char = char - 'Z'.charCodeAt(0) + 'A'.charCodeAt(0) - 1
        ret += String.fromCharCode(char)
    }
    return ret
}

function mesaj(tekst) {
    let ret = ''
    let index = 0
    let pomeraj = parseInt(document.getElementById('unos').value)
    while (ret.length < tekst.length) {
        for (let i = index ; i < tekst.length; i += pomeraj) {
            ret += tekst[i]
        }
        index++
    }
    return ret
}

function sifruj(tekst) {
    if (document.getElementById('mesanje-polje').checked) return mesaj(tekst)
    else return zameni(tekst)
}

function klik() {
    let poruka = document.getElementById('polje').value
    if (!ispravanTekst(poruka)) alert('Neispravan tekst')
    else {
        sifra = sifruj(poruka)
        $('#sifra').text(sifra)
    }
}
