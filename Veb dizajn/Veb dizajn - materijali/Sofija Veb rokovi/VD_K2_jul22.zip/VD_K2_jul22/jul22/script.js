let oznaka = 'X'
function odrediSimbol() {
    if (oznaka == 'X') {
        oznaka = 'O'
        return 'X'
    } else {
        oznaka = 'X'
        return 'O'
    }
}

function proveri() {
    if ($('td#1').text() == $('td#2').text() && $('td#1').text() == $('td#3').text() && $('td#1').text() != '') {
        $('td#1').css('background-color', 'green')
        $('td#2').css('background-color', 'green')
        $('td#3').css('background-color', 'green')
        return true;
    } else if ($('td#4').text() == $('td#5').text() && $('td#4').text() == $('td#6').text() && $('td#4').text() != '') {
        $('td#4').css('background-color', 'green')
        $('td#5').css('background-color', 'green')
        $('td#6').css('background-color', 'green')
        return true;
    } else if ($('td#7').text() == $('td#8').text() && $('td#7').text() == $('td#9').text() && $('td#7').text() != '') {
        $('td#7').css('background-color', 'green')
        $('td#8').css('background-color', 'green')
        $('td#9').css('background-color', 'green')
        return true;
    } else if ($('td#1').text() == $('td#4').text() && $('td#1').text() == $('td#7').text() && $('td#1').text() != '') {
        $('td#1').css('background-color', 'green')
        $('td#4').css('background-color', 'green')
        $('td#7').css('background-color', 'green')
        return true;
    } else if ($('td#2').text() == $('td#5').text() && $('td#2').text() == $('td#8').text() && $('td#2').text() != '') {
        $('td#2').css('background-color', 'green')
        $('td#5').css('background-color', 'green')
        $('td#8').css('background-color', 'green')
        return true;
    } else if ($('td#3').text() == $('td#6').text() && $('td#3').text() == $('td#9').text() && $('td#3').text() != '') {
        $('td#3').css('background-color', 'green')
        $('td#6').css('background-color', 'green')
        $('td#9').css('background-color', 'green')
        return true;
    } else if ($('td#1').text() == $('td#5').text() && $('td#1').text() == $('td#9').text() && $('td#1').text() != '') {
        $('td#1').css('background-color', 'green')
        $('td#5').css('background-color', 'green')
        $('td#9').css('background-color', 'green')
        return true;
    } else if ($('td#3').text() == $('td#5').text() && $('td#3').text() == $('td#7').text() && $('td#3').text() != '') {
        $('td#3').css('background-color', 'green')
        $('td#5').css('background-color', 'green')
        $('td#7').css('background-color', 'green')
        return true;
    }
}

function puno() {
    if ($('td#1').text() != '' && $('td#2').text() != '' && $('td#3').text() != '' && $('td#4').text() != '' && $('td#5').text() != '' && 
        $('td#6').text() != '' && $('td#7').text() != '' && $('td#8').text() != '' && $('td#9').text() != '') return true;
    else return false;
}

$(document).ready(function() {
    $("td").on({
        click: function() {
            let provera = $(this).text()
            if (provera != '') return;
            let simbol = odrediSimbol();
            $(this).text(simbol);
            if (proveri() == true) $('td').off()
            else if (puno() == true) {
                $('td').css('background-color', 'red')
                $('td').off()
            }
        }
    });
})