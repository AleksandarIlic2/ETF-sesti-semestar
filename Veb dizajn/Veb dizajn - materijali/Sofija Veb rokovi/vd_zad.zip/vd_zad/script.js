let bombe = ['O','O','O','O','O','O','O','O','O','O','O','O','O','O','O','O']


let temp1 = Math.floor(Math.random()*15)
let temp2 = Math.floor(Math.random()*15)
let temp3 = Math.floor(Math.random()*15)

while(temp2 == temp1 || temp2 == temp3){
    let temp2 = Math.floor(Math.random()*15)
}

while(temp3 == temp1 || temp2 == temp3){
    let temp3 = Math.floor(Math.random()*15)
}

bombe[temp1] = 'X'
bombe[temp2] = 'X'
bombe[temp3] = 'X'


for(let i = 0; i < 4; i++){
    console.log(bombe[i*4] + ' ' + bombe[i*4 + 1] + ' ' + bombe[i*4 + 2] + ' ' + bombe[i*4 + 3])
}


$(document).ready(function(){
    $(temp1).click(function(){
        $(temp1).css('background-color', "red")
    })
})

